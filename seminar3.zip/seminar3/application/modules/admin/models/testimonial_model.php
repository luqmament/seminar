<?php
 
class testimonial_model extends CI_Model {
    function __construct()
    {
         
    }

}