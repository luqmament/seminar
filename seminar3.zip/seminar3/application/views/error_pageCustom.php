<div class="member">
	<div class="container">
        <div class="row">
        	<div class="col-xs-12">
            	<div class="wrp-form">
                	<div class="row">
                    	<div class="col-xs-12">
                            <div style="position:relative;">
                               <img src="<?php echo base_url();?>assets/rewards/images/plank-1.png">
                                <p style="position:absolute; margin:-400px 0 0 180px;font-size:26px;text-align:center; color:#002244;font-weight:bold;">
                                    <span style="font-size:48px;">Maaf...</span><br>
                                    Halaman yang kamu cari tidak ditemukan
                                </p>
                                <div style="position:absolute;margin:-260px 0 0 180px;">
                                 <a href="<?php echo base_url()?>">
                                 <img src="<?php echo base_url();?>assets/rewards/images/btn-keutama.png">
                                 </a>
                                </div>
                           </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>