<div class="form-box" style="width:70%">
    <div class="header">User Registration</div>
    <div class="body">
        <p>Registrasi telah berhasil. Account anda akan diverifikasi oleh admin.</p>
    </div>        
</div>