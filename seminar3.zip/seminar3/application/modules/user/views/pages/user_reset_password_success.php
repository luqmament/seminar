<div class="form-box" style="width:70%">
    <div class="header">Reset Password</div>
    <div class="body">
        <p>Your password has been changed successfully.</p>
    </div>        
</div>