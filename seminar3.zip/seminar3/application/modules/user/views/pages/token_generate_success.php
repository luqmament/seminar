<div class="form-box" style="width:70%">
    <div class="header">Forgot Password</div>
    <div class="body">
        <p>Your reset link has been sent to your email. Please check your email. </p>
    </div>        
</div>