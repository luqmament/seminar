<html>
    <head>
        <title></title>
    </head>
    <body>
        <p>Your MG user account has been approved.</p>
        <p>You may have login now using this url</p>
        <p>Email : <?php echo $user->email ?></p>
        <p><?php echo site_url('user/login'); ?></p>

    </body>
</html>
