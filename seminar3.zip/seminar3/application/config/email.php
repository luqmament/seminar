<?php
$config['protocol'] = 'sendmail';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';

//$config = Array(
//    'protocol' => 'smtp',
//    'smtp_host' => 'ssl://smtp.googlemail.com',
//    'smtp_port' => 465,
//    'smtp_user' => 'johankristian0@gmail.com', // change it to yours
//    'smtp_pass' => 'ayambakar', // change it to yours
//    'mailtype' => 'html',
//    'charset' => 'iso-8859-1',
//    'wordwrap' => TRUE
//);
